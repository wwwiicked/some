function fun() {
            var checkbox = document.getElementById('checkbox');
            var select = document.getElementById('select');
            var opi = document.getElementById('opi');

            if (checkbox.checked) {
                opi.style.display = 'block';
                select.disable = false;
            } else {
                opi.style.display = 'none';
                opi.value = ''; 
            }
        }