<?php
session_start();
require_once __DIR__.'/db.php';
$conn = getDB();

$status = $_POST['status'];
$appid=$_POST['app_id'];



    $sql = "UPDATE `applications` SET `status` = ('$status') WHERE `id_appl` = ('$appid')";
  

    if ($conn -> query($sql) ){
       header('Location: ../adm.php');
       
    } else {
        echo "fail";
    }
