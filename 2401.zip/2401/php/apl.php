<?php
session_start();
require_once __DIR__.'/db.php'; 
$idUser = $_SESSION['user']['id'];
$adr = $_POST['adr'];
$contact = $_POST['contact'];
$data = $_POST['data'];
$time = $_POST['time'];
$oplata = $_POST['oplata'];

$select = $_POST['select'];
$opi = $_POST['opi'];

if ($opi>0){
    $usluga = $opi;
} else {
    $usluga = $select;
}


$conn = getDB();
$sql = "INSERT INTO `applications` (adr, contact, data, time, oplata, usluga, id_user) VALUE ('$adr', '$contact', '$data', '$time', '$oplata', '$usluga', '$idUser')";

if ($conn -> query($sql)===TRUE){
           
        header("Location: ../arh.php");
        } else {
            
            echo 'fail2';
        }
    
