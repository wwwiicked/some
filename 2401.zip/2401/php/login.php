<?php
session_start();

require_once __DIR__.'/db.php';
// require_once('db.php');

$login = $_POST ['login'];
$pass = $_POST['pass'];

 if ($login === 'adminka' && $pass === 'password') {
     
        $_SESSION['logged_in'] = true;
        header('Location: ../adm.php');
        exit;
 }
     
     
$sql = "SELECT * FROM `users` WHERE login= '$login' AND pass = '$pass'";
$result = $conn->query($sql); 
    if ($result->num_rows > 0){
        while ($row = $result->fetch_assoc()){
            $_SESSION['user']['id'] = $row['user_id'];
            
        
            header("Location: ../make.php");
            
        }     
        }else{
        
                echo "fail";
            
        }
