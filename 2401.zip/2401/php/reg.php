<?php

require_once __DIR__.'/db.php'; 

$login = $_POST['login'];
$pass = $_POST['pass'];
$lastname = $_POST['lastname'];
$name = $_POST['name'];
$otch = $_POST['otch'];
$phone = $_POST['phone'];
$email = $_POST['email'];

$conn = getDB();
$sql = "INSERT INTO `users` (login, pass, name, lastname, otch, phone, email) VALUE ('$login', '$pass', '$name', '$lastname', '$otch', '$phone', '$email')";

if ($conn -> query($sql)===TRUE){
           
        header("Location: ../login.html");
        } else {
            
            echo 'fail2';
        }
    

