<?php
session_start();
require_once __DIR__ . '/php/db.php';

$idUser = $_SESSION['user']['id'];

if ($idUser == '') {
    header("Location: reg.html");
}
$sql = "SELECT * FROM `users` WHERE `user_id` = ('$idUser')";

$result = mysqli_query($conn, $sql);
$result = mysqli_fetch_all($result);
foreach($result as $item) {
    
    $lastname = $item[3];
    $name = $item[4];
    
}

$sql2 = "SELECT * FROM `applications` WHERE `id_user` = ('$idUser')";

$res = mysqli_query($conn, $sql2);
$res = mysqli_fetch_all($res);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Создание заявки</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  
   <script src="main.js"></script>
  
   <div class="header">
        <div class="logo">Мой Не Сам</div>
        <nav class="menu">
          <a href="#">История заявок</a>
           <a href="make.php">Создание заявки</a>
            <a href="php/logout.php">Выход</a>
            
        </nav>
    </div>
       <div class="cont">
        <h2 style="text-align:right;"><?= $lastname ?>  <?= $name ?></h2>
       <br>
      <h1 style="text-align:center;">Ваши заявки</h1>
      <br>
<table border="1">
        <tr>
            <th>Услуга</th>
            <th>Дата</th>
             <th>Время</th>
             <th>Оплата</th>
             <th>Статус</th>
        </tr>
        <?php foreach ($res as $row): ?>
        <tr>
            <td><?php echo htmlspecialchars($row[3]); ?></td>
            <td><?php echo htmlspecialchars($row[4]); ?></td>
            <td><?php echo htmlspecialchars($row[5]); ?></td>
            <td><?php echo htmlspecialchars($row[6]); ?></td>
            <td><?php 
               if ($row[7]=='at work') {
                   $st = 'в работе';
               } else if ($row[7]=='done'){
                   $st = 'выполнена';
               } else {
                   $st = 'отменена';
               }
            echo htmlspecialchars($st); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

  
  
  </div>
  
  
  
    
   
</body>
</html>