<?php
session_start();
require_once __DIR__ . '/php/db.php';



$sql2 = "SELECT a.*, u.lastname, u.name, u.otch
FROM applications a
LEFT JOIN users u ON a.id_user = u.user_id;
";

$res = mysqli_query($conn, $sql2);
$res = mysqli_fetch_all($res);




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Создание заявки</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  
   <script src="main.js"></script>
  
   <div class="header">
        <div class="logo">Мой Не Сам</div>
        <nav class="menu">
          <a href="#">Заявки пользователей</a>
     
            <a href="php/logout.php">Выход</a>
            
        </nav>
    </div>
     <div class="cont2">
      <h1>Заявки пользователей</h1>
      <br><br>
<table style="width: 50%">
        <tr>
            <th>ФИО</th>
            <th>Адрес</th>
            <th>Номер</th>
            <th>Услуга</th>
            <th>Дата</th>
             <th>Время</th>
             <th>Оплата</th>
             <th>Статус</th>
        </tr>
        <?php foreach ($res as $row): ?>
        <tr>
          <td><?php echo htmlspecialchars($row[9]); ?> <?php echo htmlspecialchars($row[10]); ?> <?php echo htmlspecialchars($row[11]); ?></td>
           <td><?php echo htmlspecialchars($row[1]); ?></td>
           <td><?php echo htmlspecialchars($row[2]); ?></td>
            <td><?php echo htmlspecialchars($row[3]); ?></td>
            <td><?php echo htmlspecialchars($row[4]); ?></td>
            <td><?php echo htmlspecialchars($row[5]); ?></td>
            <td><?php echo htmlspecialchars($row[6]); ?></td>
            <td> 
         <form class="up" method="POST" action="php/update.php">
                         <input type="hidden" name="app_id" value="<?= htmlspecialchars($row[0]) ?>">
                         
                         
                         <select name="status" class="status-select" onchange="this.form.submit()">
                           <option value="at work" <?= $row[7] === 'at work' ? 'selected' : '' ?>>в работе</option>
                           <option value="done" <?= $row[7] === 'done' ? 'selected' : '' ?>>выполнена</option>
                           <option value="cancel" <?= $row[7] === 'cancel' ? 'selected' : '' ?>>отменена</option>
                         </select>
                         
                         
                </form>
                
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

  
  
  </div>
  
  
  
    
   
</body>
</html>