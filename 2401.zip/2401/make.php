<?php

session_start();

require_once __DIR__ . '/php/db.php';



$idUser = $_SESSION['user']['id'];

if ($idUser == '') {
    header("Location: reg.html");
}

$sql = "SELECT * FROM `users` WHERE `user_id` = ('$idUser')";


$result = mysqli_query($conn, $sql);
$result = mysqli_fetch_all($result);


foreach($result as $item) {
    
    $lastname = $item[3];
    $name = $item[4];
    
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Создание заявки</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  
   <script src="main.js"></script>
  
   <div class="header">
        <div class="logo">Мой Не Сам</div>
        <nav class="menu">
          <a href="arh.php">История заявок</a>
           <a href="#">Создание заявки</a>
            <a href="php/logout.php">Выход</a>
            
        </nav>
    </div>
      
      <div class="cont">
      
       <h2 style="text-align:right;">Добро пожаловать! <?= $lastname ?>  <?= $name ?></h2>
       <br>
      <h1 style="text-align:center;">Оформление заявки на услугу</h1>
    <form class="make" action="php/apl.php" method="post">
    
      
<!--pattern="^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$"-->
   

     

        <table style="width:100%">
       
        <tr>
            <td>Адрес:</td>
            <td><input type="text" name="adr" placeholder="Введите ваш адрес" required></td>
        </tr>
        <tr>
            <td> Контактный телефон:</td>
            <td><input type="tel" name="contact" placeholder="+7(___)-___-__-__"  title="Введите номер телефона в формате +7(XXX)-XXX-XX-XX" required></td>
        </tr>
        <tr>
            <td>Желаемая дата и время:</td>
            <td>      <input type="date" id="data" name="data" required>
            <input type="time" id="time" name="time" required></td>
        </tr>
        <tr>
            <td>Выберите вид услуги:</td>
            <td>     <select id="select" name="select" >
            <option value="" disabled selected hidden>Выберите вид услуги</option>
            <option >Общий клининг</option>
            <option >Генеральная уборка</option>
            <option >Послестроительная уборка</option>
            <option >Химчистка ковров и мебели</option>
        </select>

 
            <input type="checkbox" id="checkbox" onclick="fun()">
            Иная услуга

            <textarea id="opi" name="opi" rows="4" cols="60" placeholder="Опишите необходимую услугу"></textarea></td>
        </tr>
        <tr>
            <td>Способ оплаты:</td>
            <td><select id="select" name="oplata" required>
                <option value="" disabled selected hidden>Выберите способ оплаты</option>
                <option>Наличные</option>
                <option>Банковская карта</option>
            </select></td>
        </tr>
    </table>

        <input type="submit" class="but" value="Отправить заявку">
    </form>

  
  
  </div>
  
  
  
    
   
</body>
</html>